package Portafolio_DesarolloWEB.portafolio.domain;

import jakarta.persistence.*;
import lombok.Data;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "reservacion")
public class Reservacion implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idReservacion;

    private String nombreCliente;
    private LocalDate fecha;
    private LocalTime hora;
    private boolean activo; // To indicate if the reservation is active or cancelled

    // Constructor vacío requerido por JPA
    public Reservacion() {
    }
}