package Portafolio_DesarolloWEB.portafolio.service;

import Portafolio_DesarolloWEB.portafolio.domain.Reservacion;
import java.util.List;

public interface ReservacionService {


    List<Reservacion> getReservaciones();


    Reservacion getReservacion(Reservacion reservacion);


    void save(Reservacion reservacion);


    void delete(Reservacion reservacion);
}