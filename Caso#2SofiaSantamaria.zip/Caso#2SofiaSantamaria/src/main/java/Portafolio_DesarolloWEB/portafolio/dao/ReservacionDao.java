package Portafolio_DesarolloWEB.portafolio.dao;

import Portafolio_DesarolloWEB.portafolio.domain.Reservacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservacionDao extends JpaRepository<Reservacion, Long> {
}