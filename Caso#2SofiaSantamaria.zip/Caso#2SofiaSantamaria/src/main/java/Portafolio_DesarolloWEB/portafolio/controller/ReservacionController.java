package Portafolio_DesarolloWEB.portafolio.controller;

import Portafolio_DesarolloWEB.portafolio.domain.Reservacion;
import Portafolio_DesarolloWEB.portafolio.service.ReservacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reservacion")
public class ReservacionController {

    @Autowired
    private ReservacionService reservacionService;

    @GetMapping("/listado")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_VENDEDOR')")
    public String listado(Model model) {
        var reservaciones = reservacionService.getReservaciones();
        model.addAttribute("reservaciones", reservaciones);
        model.addAttribute("totalReservaciones", reservaciones.size());
        return "Reservas/listado";
    }

    @GetMapping("/nuevo")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String reservacionNuevo(Reservacion reservacion) {
        return "Reservas/modifica";
    }

    @PostMapping("/guardar")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String reservacionGuardar(Reservacion reservacion) {
        reservacionService.save(reservacion);
        return "redirect:/reservacion/listado";
    }

    @GetMapping("/modificar/{idReservacion}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String reservacionModificar(@PathVariable("idReservacion") Long idReservacion, Model model) {
        Reservacion reservacion = new Reservacion();
        reservacion.setIdReservacion(idReservacion);
        reservacion = reservacionService.getReservacion(reservacion);
        model.addAttribute("reservacion", reservacion);
        return "Reservas/modifica";
    }

    @GetMapping("/eliminar/{idReservacion}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public String reservacionEliminar(@PathVariable("idReservacion") Long idReservacion) {
        Reservacion reservacion = new Reservacion();
        reservacion.setIdReservacion(idReservacion);
        reservacionService.delete(reservacion);
        return "redirect:/reservacion/listado";
    }
}