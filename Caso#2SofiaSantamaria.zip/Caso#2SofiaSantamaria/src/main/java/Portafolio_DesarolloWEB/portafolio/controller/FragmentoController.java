/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Portafolio_DesarolloWEB.portafolio.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/fragmento") // La base de la ruta es /fragmento
public class FragmentoController {

    @GetMapping("") // Mapea a /fragmento
    public String mostrarFragmentoRaiz() {
        return "usuario/Fragmento"; // Asegúrate de que la ruta de la vista sea correcta
    }

    @GetMapping("/pagina") // Mapea a /fragmento/pagina
    public String mostrarOtraPaginaFragmento() {
        return "Fragmento"; // Ejemplo de otra página
    }
}