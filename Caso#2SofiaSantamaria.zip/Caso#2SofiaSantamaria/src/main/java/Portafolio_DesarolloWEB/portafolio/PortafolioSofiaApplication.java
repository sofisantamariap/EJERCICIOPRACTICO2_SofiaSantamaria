package Portafolio_DesarolloWEB.portafolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortafolioSofiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortafolioSofiaApplication.class, args);
	}

}
