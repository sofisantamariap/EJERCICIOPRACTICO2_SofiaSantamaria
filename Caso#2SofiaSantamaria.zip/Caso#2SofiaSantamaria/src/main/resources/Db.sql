DROP SCHEMA IF EXISTS biblioteca;
DROP USER IF EXISTS usuario_prueba;
CREATE SCHEMA biblioteca;

-- Fixed typo in password
CREATE USER 'usuario_prueba'@'%' IDENTIFIED BY 'Biblioteca';

GRANT ALL PRIVILEGES ON biblioteca.* TO 'usuario_prueba'@'%';
FLUSH PRIVILEGES;

USE biblioteca;

CREATE TABLE categoria (
  id_categoria INT NOT NULL AUTO_INCREMENT,
  descripcion VARCHAR(30) NOT NULL,
  ruta_imagen VARCHAR(1024),
  activo BOOL,
  PRIMARY KEY (id_categoria)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

CREATE TABLE producto (
  id_producto INT NOT NULL AUTO_INCREMENT,
  id_categoria INT NOT NULL,
  descripcion VARCHAR(30) NOT NULL,  
  detalle VARCHAR(1600) NOT NULL, 
  precio DOUBLE,
  existencias INT,  
  ruta_imagen VARCHAR(1024),
  activo BOOL,
  PRIMARY KEY (id_producto),
  -- Fixed typo in foreign key name
  FOREIGN KEY fk_producto_categoria (id_categoria) REFERENCES categoria(id_categoria)  
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

CREATE TABLE usuario (
  id_usuario INT NOT NULL AUTO_INCREMENT,
  username VARCHAR(20) NOT NULL,
  password VARCHAR(512) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apellidos VARCHAR(30) NOT NULL,
  correo VARCHAR(75) NULL,
  telefono VARCHAR(15) NULL,
  ruta_imagen VARCHAR(1024),
  activo BOOLEAN,
  PRIMARY KEY (id_usuario)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

CREATE TABLE factura (
  id_factura INT NOT NULL AUTO_INCREMENT,
  id_usuario INT NOT NULL,
  fecha DATE,  
  total DOUBLE,
  estado INT,
  PRIMARY KEY (id_factura),
  FOREIGN KEY fk_factura_usuario (id_usuario) REFERENCES usuario(id_usuario)  
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

CREATE TABLE venta (
  id_venta INT NOT NULL AUTO_INCREMENT,
  id_factura INT NOT NULL,
  id_producto INT NOT NULL,
  precio DOUBLE, 
  cantidad INT,
  PRIMARY KEY (id_venta),
  FOREIGN KEY fk_ventas_factura (id_factura) REFERENCES factura(id_factura),
  FOREIGN KEY fk_ventas_producto (id_producto) REFERENCES producto(id_producto) 
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

/*Se insertan registros en la tabla usuario como ejemplo */
INSERT INTO usuario (id_usuario, username, password, nombre, apellidos, correo, telefono, ruta_imagen, activo) VALUES 
(1, 'juan', '$2a$10$P1.w58XvnaYQUQgZUCk4aO/RTRl8EValluCqB3S2VMLTbRt.tlre.', 'Juan', 'Castro Mora', 'jcastro@gmail.com', '4556-8978', 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Juan_Diego_Madrigal.jpg/250px-Juan_Diego_Madrigal.jpg', true),
(2, 'rebeca', '$2a$10$GkEj.ZzmQa/aEfDmtLIh3udIH5fMphx/35d0EYeqZL5uzgCJ0lQRi', 'Rebeca', 'Contreras Mora', 'acontreras@gmail.com', '5456-8789', 'https://upload.wikimedia.org/wikipedia/commons/0/06/Photo_of_Rebeca_Arthur.jpg', true),
(3, 'pedro', '$2a$10$koGR7eS22Pv5KdaVJKDcge04ZB53iMiw76.UjHPY.XyVYlYqXnPbO', 'Pedro', 'Mena Loria', 'lmena@gmail.com', '7898-8936', 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Eduardo_de_Pedro_2019.jpg/480px-Eduardo_de_Pedro_2019.jpg?20200109230854', true),
-- Fixed password to use hashed format like other users
(4, 'sebas', '$2a$10$P1.w58XvnaYQUQgZUCk4aO/RTRl8EValluCqB3S2VMLTbRt.tlre.', 'Sebas', 'Vasquez', 'svasquez@gmail.com', '4556-8978', 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Juan_Diego_Madrigal.jpg/250px-Juan_Diego_Madrigal.jpg', true);

-- Added the missing category (5) and aligned descriptions with actual book categories
INSERT INTO categoria (id_categoria, descripcion, ruta_imagen, activo) VALUES 
(1, 'Fantasia', 'https://d2ulnfq8we0v3.cloudfront.net/cdn/695858/media/catalog/category/MONITORES.jpg', true), 
(2, 'Manga', 'https://cnnespanol.cnn.com/wp-content/uploads/2022/04/teclado-mecanico.jpg', true),
(3, 'Ciencia', 'https://static-geektopia.com/storage/thumbs/784x311/788/7884251b/98c0f4a5.webp', true),
(4, 'Historia', 'https://www.monumental.co.cr/wp-content/uploads/2022/03/X4J2Z6XQUZDO7O6QTDF4DIJ3VE.jpeg', false),
(5, 'Literatura', 'https://imagessl7.casadellibro.com/m/casadellibro/images/libros/9/9788497592009.jpg', true);

-- Add all products referenced in the venta table
INSERT INTO producto (id_producto, id_categoria, descripcion, detalle, precio, existencias, ruta_imagen, activo) VALUES
(1, 1, 'Misión Imposible 5', 'Ethan Hunt contra el Sindicato.', 35000, 10, 'https://m.media-amazon.com/images/M/MV5BOTFmNDA3Mjk0NF5BMl5BanBnXkFtZTgwMzA5NTYxMDI@._V1_FMjpg_UX1000_.jpg', true),
(2, 2, 'Superbad', 'Dos amigos buscan alcohol para una fiesta.', 28000, 15, 'https://m.media-amazon.com/images/M/MV5BMzIzYjM2YTYtYzRmOC00YjVlLTlmYjUtMTE5MzU1MWEzM2NE._V1_FMjpg_UX1000_.jpg', true),
(3, 3, 'El viaje de Chihiro', 'Niña en un mundo mágico.', 22000, 20, 'https://m.media-amazon.com/images/M/MV5BNGIzOTYzNmUtOTQzYi00YzRhLWEzYWEtN2Q3NWNmZWYwYzM1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_FMjpg_UX1000_.jpg', true),
(5, 1, 'Mad Max: Furia en la carretera', 'Rebelión en el páramo postapocalíptico.', 40000, 8, 'https://m.media-amazon.com/images/M/MV5BN2MwMmM0YmQtMTVkOC00NzkwLTk2OWYtMzA2N2UwM2EwYjQ0XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_FMjpg_UX1000_.jpg', true),
(6, 4, 'La La Land', 'Romance musical en Los Ángeles.', 32000, 12, 'https://m.media-amazon.com/images/M/MV5BNGM0YWYwYmQtZWI5Ni00M2YzLWFmNjAtMTc0ZTkzNzMxMmI2XkEyXkFqcGdeQXVyMDM5OTQyMQ@@._V1_FMjpg_UX1000_.jpg', true),
(8, 3, 'Your Name.', 'Adolescentes intercambian cuerpos.', 25000, 18, 'https://m.media-amazon.com/images/M/MV5BODRmZDVmNzUtMDYxYi00YjkyLWEyNmEtYjM0YzFjNmI4YzIzXkEyXkFqcGdeQXVyNTk0MzMzNjE@._V1_FMjpg_UX1000_.jpg', true),
(9, 2, 'Ted', 'Un hombre y su oso de peluche parlante.', 29000, 14, 'https://m.media-amazon.com/images/M/MV5BMTc1NjIzMjYxOV5BMl5BanBnXkFtZTcwMjk3Mzg3OA@@._V1_FMjpg_UX1000_.jpg', true),
(10, 4, 'Diario de una pasión', 'Un amor de verano separado por clases.', 31000, 11, 'https://m.media-amazon.com/images/M/MV5BNzgxOTEwMjI1NF5BMl5BanBnXkFtZTcwNjkyNjUyMw@@._V1_FMjpg_UX1000_.jpg', true),
(12, 1, 'Avengers: Endgame', 'Los Vengadores contra Thanos.', 45000, 7, 'https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_FMjpg_UX1000_.jpg', true),
(14, 2, '¿Qué pasó ayer?', 'Despedida de soltero caótica en Las Vegas.', 30000, 13, 'https://m.media-amazon.com/images/M/MV5BNjQ0ODk3NzY4Ml5BMl5BanBnXkFtZTcwNjg2NjYxMw@@._V1_FMjpg_UX1000_.jpg', true),
(15, 3, 'La princesa Mononoke', 'Guerra entre humanos y dioses del bosque.', 26000, 16, 'https://m.media-amazon.com/images/M/MV5BNGIzOTYzNmUtOTQzYi00YzRhLWEzYWEtN2Q3NWNmZWYwYzM1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_FMjpg_UX1000_.jpg', true);
INSERT INTO factura (id_factura, id_usuario, fecha, total, estado) VALUES
(1, 1, '2022-01-05', 211560, 2),
(2, 2, '2022-01-07', 554340, 2),
(3, 3, '2022-01-07', 871000, 2),
(4, 1, '2022-01-15', 244140, 1),
(5, 2, '2022-01-17', 414800, 1),
(6, 3, '2022-01-21', 420000, 1);

INSERT INTO venta (id_venta, id_factura, id_producto, precio, cantidad) values
(1, 1, 5, 45000, 3),
(2, 1, 9, 15780, 2),
(3, 1, 10, 15000, 3),
(4, 2, 5, 45000, 1),
(5, 2, 14, 154000, 3),
(6, 2, 9, 15780, 3),
(7, 3, 14, 154000, 1),
(8, 3, 6, 57000, 1),
(9, 3, 15, 330000, 2),
(10, 1, 6, 57000, 2),
(11, 1, 8, 27600, 3),
(12, 1, 9, 15780, 3),
(13, 2, 8, 27600, 3),
(14, 2, 14, 154000, 2),
(15, 2, 3, 24000, 1),
(16, 3, 15, 330000, 1),
(17, 3, 12, 45000, 1),
(18, 3, 10, 15000, 3);

CREATE TABLE rol (
  id_rol INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(20),
  id_usuario INT,
  PRIMARY KEY (id_rol),
  FOREIGN KEY fk_rol_usuario (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

INSERT INTO rol (id_rol, nombre, id_usuario) VALUES
 (1, 'ROLE_ADMIN', 1), (2, 'ROLE_VENDEDOR', 1), (3, 'ROLE_USER', 1),
 (4, 'ROLE_VENDEDOR', 2), (5, 'ROLE_USER', 2),
 (6, 'ROLE_USER', 3),
 (7, 'ROLE_USER', 4);

CREATE TABLE request_matcher (
    id_request_matcher INT AUTO_INCREMENT NOT NULL,
    pattern VARCHAR(255) NOT NULL,
    role_name VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_request_matcher)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- Fixed role names to match those in the rol table
INSERT INTO request_matcher (pattern, role_name) VALUES 
('/producto/nuevo', 'ROLE_ADMIN'),
('/producto/guardar', 'ROLE_ADMIN'),
('/producto/modificar/**', 'ROLE_ADMIN'),
('/producto/eliminar/', 'ROLE_ADMIN'),
('/categoria/nuevo', 'ROLE_ADMIN'),
('/categoria/guardar', 'ROLE_ADMIN'),
('/categoria/modificar/**', 'ROLE_ADMIN'),
('/categoria/eliminar/', 'ROLE_ADMIN'),
('/usuario/nuevo', 'ROLE_ADMIN'),
('/usuario/guardar', 'ROLE_ADMIN'),
('/usuario/modificar/**', 'ROLE_ADMIN'),
('/usuario/eliminar/', 'ROLE_ADMIN'),
('/reportes/', 'ROLE_ADMIN'),
('/producto/listado', 'ROLE_VENDEDOR'),
('/categoria/listado', 'ROLE_VENDEDOR'),
('/usuario/listado', 'ROLE_VENDEDOR'),
('/facturar/carrito', 'ROLE_USER');

CREATE TABLE request_matcher_all (
    id_request_matcher INT AUTO_INCREMENT NOT NULL,
    pattern VARCHAR(255) NOT NULL,
    PRIMARY KEY (id_request_matcher)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

INSERT INTO request_matcher_all (pattern) VALUES 
('/'),
('/index'),
('/errores/'),
('/carrito/'),
('/pruebas/'),
('/reportes/'),
('/registro/'),
('/js/'),
('/webjars/');