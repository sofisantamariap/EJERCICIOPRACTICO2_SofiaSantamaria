package Portafolio_DesarolloWEB.portafolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortafolioSebastianVasquezApplicationTests {

	@Test
	void contextLoads() {
	}

}
